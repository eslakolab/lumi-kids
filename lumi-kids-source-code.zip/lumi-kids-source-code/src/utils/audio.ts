// Audio synthesizer and Arabic Speech Engine for slow learners

class AudioEngine {
  private ctx: AudioContext | null = null;

  private getContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    return this.ctx;
  }

  // Play a cheerful chime when child succeeds
  playSuccessChime() {
    try {
      const ctx = this.getContext();
      if (!ctx) return;
      const notes = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6
      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, ctx.currentTime + idx * 0.1);

        gain.gain.setValueAtTime(0.001, ctx.currentTime + idx * 0.1);
        gain.gain.exponentialRampToValueAtTime(0.2, ctx.currentTime + idx * 0.1 + 0.04);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + idx * 0.1 + 0.4);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(ctx.currentTime + idx * 0.1);
        osc.stop(ctx.currentTime + idx * 0.1 + 0.45);
      });
    } catch {
      // Ignore audio context errors if blocked by browser policy
    }
  }

  // Soft, warm encouragement tone (never harsh, safe for sensitive children)
  playEncouragementChime() {
    try {
      const ctx = this.getContext();
      if (!ctx) return;
      const notes = [392.00, 440.00, 523.25]; // G4, A4, C5
      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, ctx.currentTime + idx * 0.12);

        gain.gain.setValueAtTime(0.001, ctx.currentTime + idx * 0.12);
        gain.gain.exponentialRampToValueAtTime(0.15, ctx.currentTime + idx * 0.12 + 0.05);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + idx * 0.12 + 0.35);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(ctx.currentTime + idx * 0.12);
        osc.stop(ctx.currentTime + idx * 0.12 + 0.4);
      });
    } catch {}
  }

  // Playful pop bubble on clicking interactive elements
  playPop() {
    try {
      const ctx = this.getContext();
      if (!ctx) return;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(400, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(800, ctx.currentTime + 0.08);

      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.08);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.09);
    } catch {}
  }

  // Playful laughter / sparkle chirp when the star mascot is clicked
  playStarSparkle() {
    try {
      const ctx = this.getContext();
      if (!ctx) return;
      const freqs = [659.25, 880, 1174.66, 1318.51, 1567.98];
      freqs.forEach((freq, i) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, ctx.currentTime + i * 0.07);

        gain.gain.setValueAtTime(0.001, ctx.currentTime + i * 0.07);
        gain.gain.exponentialRampToValueAtTime(0.18, ctx.currentTime + i * 0.07 + 0.03);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + i * 0.07 + 0.25);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(ctx.currentTime + i * 0.07);
        osc.stop(ctx.currentTime + i * 0.07 + 0.28);
      });
    } catch {}
  }

  // Counting item sound (rises with number)
  playCountTone(countIndex: number) {
    try {
      const ctx = this.getContext();
      if (!ctx) return;
      const baseFreq = 300 + Math.min(countIndex, 12) * 50;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(baseFreq, ctx.currentTime);

      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.15);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.16);
    } catch {}
  }

  // Speak text clearly with child-friendly speed and voice
  speak(text: string, lang: 'ar' | 'en' = 'ar', rate: number = 0.75, onEnd?: () => void) {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      if (onEnd) onEnd();
      return;
    }

    window.speechSynthesis.cancel(); // Stop any pending speech

    let processedText = text;
    if (lang === 'ar') {
      // Pedagogical Arabic Phonics: An isolated consonant with sukoon cannot be vocalized in isolation ("لا يبدأ بساكن")
      // Convert standalone consonants with sukoon (e.g. "تْ") into their audible vocalization ("أَتْ")
      const sukoonMap: Record<string, string> = {
        'أ': 'أَءْ', 'ء': 'أَءْ', 'ا': 'أَءْ', 'ب': 'أَبْ', 'ت': 'أَتْ', 'ث': 'أَثْ',
        'ج': 'أَجْ', 'ح': 'أَحْ', 'خ': 'أَخْ', 'د': 'أَدْ', 'ذ': 'أَذْ', 'ر': 'أَرْ',
        'ز': 'أَزْ', 'س': 'أَسْ', 'ش': 'أَشْ', 'ص': 'أَصْ', 'ض': 'أَضْ', 'ط': 'أَطْ',
        'ظ': 'أَظْ', 'ع': 'أَعْ', 'غ': 'أَغْ', 'ف': 'أَفْ', 'ق': 'أَقْ', 'ك': 'أَكْ',
        'ل': 'أَلْ', 'م': 'أَمْ', 'ن': 'أَنْ', 'ه': 'أَهْ', 'هـ': 'أَهْ', 'و': 'أَوْ',
        'ي': 'أَيْ', 'ة': 'أَهْ'
      };

      // Match standalone consonant followed by sukoon or isolated letter
      processedText = processedText.replace(/(^|[\s.,؛:«»"()\-–—])([بتثجحخدذرزسشصضطظعغفقكلمنهويءأ])ْ(?=[\s.,؛:«»"()\-–—]|$)/g, (_match, prefix, char) => {
        return `${prefix}${sukoonMap[char] || `أَ${char}ْ`}`;
      });
    }

    const utterance = new SpeechSynthesisUtterance(processedText);
    utterance.lang = lang === 'ar' ? 'ar-SA' : 'en-US';
    utterance.rate = rate; // Slower cadence for comprehension
    utterance.pitch = 1.15; // Friendly slightly higher pitch for children

    const voices = window.speechSynthesis.getVoices();
    if (lang === 'ar') {
      const arVoice = voices.find(v => v.lang.startsWith('ar') || v.lang.includes('Arabic'));
      if (arVoice) utterance.voice = arVoice;
    } else {
      // Find friendly English voice
      const enVoice = voices.find(v => 
        (v.lang.startsWith('en') || v.lang.includes('English')) && 
        (v.name.includes('Natural') || v.name.includes('Google') || v.name.includes('Samantha') || v.name.includes('Karen') || v.name.includes('Victoria') || v.name.includes('Jenny') || v.name.includes('Zira'))
      ) || voices.find(v => v.lang.startsWith('en'));
      if (enVoice) utterance.voice = enVoice;
    }

    if (onEnd) {
      utterance.onend = () => onEnd();
      utterance.onerror = () => onEnd();
    }

    window.speechSynthesis.speak(utterance);
  }

  // Pronounce Arabic text (backwards compatible alias)
  speakArabic(text: string, rate: number = 0.75, onEnd?: () => void) {
    this.speak(text, 'ar', rate, onEnd);
  }

  // Pronounce English text clearly for children
  speakEnglish(text: string, rate: number = 0.8, onEnd?: () => void) {
    this.speak(text, 'en', rate, onEnd);
  }
}

export const soundManager = new AudioEngine();
