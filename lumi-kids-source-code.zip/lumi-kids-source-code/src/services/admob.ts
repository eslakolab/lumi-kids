// Google AdMob Service for Children's Educational Apps
// Compliant with Google Play Families Policy, COPPA, and Apple App Store Kids Category guidelines

export interface AdMobConfig {
  appIdAndroid: string;
  appIdIos: string;
  bannerAdUnitIdAndroid: string;
  bannerAdUnitIdIos: string;
  interstitialAdUnitIdAndroid: string;
  interstitialAdUnitIdIos: string;
  rewardedAdUnitIdAndroid: string;
  rewardedAdUnitIdIos: string;
  // Mandatory Child Safety COPPA flags
  isTesting: boolean;
  maxAdContentRating: 'G'; // Strictly G-rated family safe
  tagForChildDirectedTreatment: true; // Mandatory COPPA compliance
  tagForUnderAgeOfConsent: true;
}

export const ADMOB_DEFAULT_CONFIG: AdMobConfig = {
  appIdAndroid: 'ca-app-pub-3940256099942544~3347511713', // Official Google Test App ID
  appIdIos: 'ca-app-pub-3940256099942544~1458602516',
  bannerAdUnitIdAndroid: 'ca-app-pub-3940256099942544/6300978111', // Test Banner ID
  bannerAdUnitIdIos: 'ca-app-pub-3940256099942544/2934735716',
  interstitialAdUnitIdAndroid: 'ca-app-pub-3940256099942544/1033173712',
  interstitialAdUnitIdIos: 'ca-app-pub-3940256099942544/4411468910',
  rewardedAdUnitIdAndroid: 'ca-app-pub-3940256099942544/5224354917',
  rewardedAdUnitIdIos: 'ca-app-pub-3940256099942544/1712485313',
  isTesting: true,
  maxAdContentRating: 'G',
  tagForChildDirectedTreatment: true,
  tagForUnderAgeOfConsent: true,
};

export interface SafeChildAd {
  id: string;
  sponsorName: string;
  title: string;
  description: string;
  callToAction: string;
  badgeText: string;
  icon: string;
}

// Child-safe educational sponsor creatives displayed when native AdMob SDK is not present or for fallback
export const SAFE_CHILD_ADS: SafeChildAd[] = [
  {
    id: 'ad_1',
    sponsorName: 'مُبَادَرَةُ الْقِرَاءَةِ لِلْأَطْفَالِ',
    title: 'تَحَدِّي الْقِرَاءَةِ الْمُمْتِعِ',
    description: 'اقْرَأْ كِتَابًا صَغِيرًا كُلَّ يَوْمٍ وَاكْتَشِفْ عَالَمَ الْمَعْرِفَةِ!',
    callToAction: 'اقْرَأْ مَعَنَا',
    badgeText: 'إِعْلَانٌ تَعْلِيمِيٌّ مُنَاسِبٌ لِلْأَطْفَالِ',
    icon: '📚',
  },
  {
    id: 'ad_2',
    sponsorName: 'عَالَمُ الْعُلُومِ وَالْفَضَاءِ',
    title: 'رِحْلَةٌ نَحْوَ النُّجُومِ وَالْكَوَاكِبِ',
    description: 'شَاهِدْ صُوَرَ الْقَمَرِ وَالشَّمْسِ وَتَعَلَّمْ أَسْرَارَ الْكَوْنِ الْعَجِيبِ!',
    callToAction: 'اكْتَشِفِ الْآنَ',
    badgeText: 'إِعْلَانٌ تَعْلِيمِيٌّ مُنَاسِبٌ لِلْأَطْفَالِ',
    icon: '🚀',
  },
  {
    id: 'ad_3',
    sponsorName: 'نَادِي الْفُنُونِ وَالرَّسْمِ',
    title: 'لَوْنْ حَيَاتَكَ بِأَجْمَلِ الْأَلْوَانِ',
    description: 'اسْتَخْدِمِ الْفُرْشَاةَ وَعَبِّرْ عَنْ إِبْدَاعِكَ فِي مَرْسَمِ الطِّفْلِ.',
    callToAction: 'ارْسُمْ مَعَنَا',
    badgeText: 'إِعْلَانٌ تَعْلِيمِيٌّ مُنَاسِبٌ لِلْأَطْفَالِ',
    icon: '🎨',
  },
];

class AdMobManager {
  private isInitialized = false;
  private isSubscribed = false;

  public initialize(isSubscribed: boolean) {
    this.isSubscribed = isSubscribed;
    this.isInitialized = true;
    console.log('[AdMob] Initialized with COPPA settings (G-rated, child-directed, safe). Subscribed:', isSubscribed);
  }

  public updateSubscriptionStatus(isSubscribed: boolean) {
    this.isSubscribed = isSubscribed;
    if (isSubscribed) {
      console.log('[AdMob] User subscribed: all ads immediately suppressed.');
    }
  }

  public canShowAds(): boolean {
    return !this.isSubscribed;
  }

  public getRandomSafeAd(): SafeChildAd {
    const idx = Math.floor(Math.random() * SAFE_CHILD_ADS.length);
    return SAFE_CHILD_ADS[idx];
  }
}

export const adMobManager = new AdMobManager();
