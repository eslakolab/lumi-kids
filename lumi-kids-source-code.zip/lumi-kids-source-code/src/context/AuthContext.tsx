import React, { createContext, useContext, useState, useEffect } from 'react';

export type AuthProviderType = 'google' | 'apple' | 'email';

export interface UserProfile {
  id: string;
  email: string;
  name: string;
  provider: AuthProviderType;
  avatarUrl?: string;
  role: 'user' | 'admin';
  createdAt: string;
}

export interface ChildProgress {
  completedLetters: string[];
  completedWords: string[];
  spellingScore: number;
  starsCount: number;
  storiesRead: string[];
  mathScore: number;
  lastSyncedAt: string;
}

interface AuthContextType {
  user: UserProfile | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  progress: ChildProgress;
  isSyncing: boolean;
  lastSyncMessage: string | null;
  loginWithGoogle: () => Promise<boolean>;
  loginWithApple: () => Promise<boolean>;
  loginWithEmail: (email: string, pass: string) => Promise<{ success: boolean; message: string }>;
  registerWithEmail: (email: string, pass: string, name: string) => Promise<{ success: boolean; message: string }>;
  recoverPassword: (email: string) => Promise<{ success: boolean; message: string }>;
  logout: () => void;
  syncProgressNow: () => Promise<void>;
  addCompletedLetter: (letterId: string) => void;
  addCompletedWord: (wordId: string) => void;
  addStars: (amount: number) => void;
}

const LOCAL_AUTH_USER_KEY = 'lumi_auth_user_v1';
const LOCAL_CHILD_PROGRESS_KEY = 'lumi_child_progress_v1';

const INITIAL_PROGRESS: ChildProgress = {
  completedLetters: ['alif', 'baa'],
  completedWords: ['أَبٌ', 'أُمٌّ'],
  spellingScore: 10,
  starsCount: 15,
  storiesRead: ['story_1'],
  mathScore: 8,
  lastSyncedAt: new Date().toISOString(),
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserProfile | null>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_AUTH_USER_KEY);
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [progress, setProgress] = useState<ChildProgress>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_CHILD_PROGRESS_KEY);
      return saved ? JSON.parse(saved) : INITIAL_PROGRESS;
    } catch {
      return INITIAL_PROGRESS;
    }
  });

  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [lastSyncMessage, setLastSyncMessage] = useState<string | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_CHILD_PROGRESS_KEY, JSON.stringify(progress));
    } catch (e) {
      console.error(e);
    }
  }, [progress]);

  const saveUserSession = (newUser: UserProfile | null) => {
    setUser(newUser);
    if (newUser) {
      localStorage.setItem(LOCAL_AUTH_USER_KEY, JSON.stringify(newUser));
      syncProgressNow();
    } else {
      localStorage.removeItem(LOCAL_AUTH_USER_KEY);
    }
  };

  const loginWithGoogle = async (): Promise<boolean> => {
    setIsLoading(true);
    // Real OAuth flow simulation / client connection
    await new Promise((r) => setTimeout(r, 600));
    const googleUser: UserProfile = {
      id: 'google_user_' + Date.now(),
      email: 'parent.google@example.com',
      name: 'عَائِلَةُ لُومِي (Google)',
      provider: 'google',
      avatarUrl: '/src/assets/images/avatar_boy_explorer_1793016699238.jpg',
      role: 'user',
      createdAt: new Date().toISOString(),
    };
    saveUserSession(googleUser);
    setIsLoading(false);
    return true;
  };

  const loginWithApple = async (): Promise<boolean> => {
    setIsLoading(true);
    // Apple ID sign-in simulation
    await new Promise((r) => setTimeout(r, 600));
    const appleUser: UserProfile = {
      id: 'apple_user_' + Date.now(),
      email: 'parent.apple@icloud.com',
      name: 'حِسَابُ Apple ID',
      provider: 'apple',
      role: 'user',
      createdAt: new Date().toISOString(),
    };
    saveUserSession(appleUser);
    setIsLoading(false);
    return true;
  };

  const loginWithEmail = async (email: string, pass: string): Promise<{ success: boolean; message: string }> => {
    setIsLoading(true);
    await new Promise((r) => setTimeout(r, 600));
    if (!email || !pass) {
      setIsLoading(false);
      return { success: false, message: 'يُرْجَى إِدْخَالُ الْبَرِيدِ الْإِلِكْتَرُونِيِّ وَكَلِمَةِ الْمُرُورِ' };
    }

    // Admin detection for CMS demonstration
    const isAdmin = email.toLowerCase().includes('admin');
    const emailUser: UserProfile = {
      id: 'email_user_' + Date.now(),
      email,
      name: isAdmin ? 'مُدِيرُ النِّظَامِ (Admin)' : email.split('@')[0],
      provider: 'email',
      role: isAdmin ? 'admin' : 'user',
      createdAt: new Date().toISOString(),
    };
    saveUserSession(emailUser);
    setIsLoading(false);
    return { success: true, message: 'تَمَّ تَسْجِيلُ الدُّخُولِ بِنَجَاح!' };
  };

  const registerWithEmail = async (
    email: string,
    pass: string,
    name: string
  ): Promise<{ success: boolean; message: string }> => {
    setIsLoading(true);
    await new Promise((r) => setTimeout(r, 600));
    if (!email || !pass) {
      setIsLoading(false);
      return { success: false, message: 'يُرْجَى مَلْءُ كَافَّةِ الْحُقُولِ الْمَطْلُوبَةِ' };
    }
    const newUser: UserProfile = {
      id: 'email_user_' + Date.now(),
      email,
      name: name || email.split('@')[0],
      provider: 'email',
      role: email.toLowerCase().includes('admin') ? 'admin' : 'user',
      createdAt: new Date().toISOString(),
    };
    saveUserSession(newUser);
    setIsLoading(false);
    return { success: true, message: 'تَمَّ إِنْشَاءُ الْحِسَابِ وَحِفْظُ بَيَانَاتِ الطِّفْلِ بِنَجَاح!' };
  };

  const recoverPassword = async (email: string): Promise<{ success: boolean; message: string }> => {
    setIsLoading(true);
    await new Promise((r) => setTimeout(r, 700));
    setIsLoading(false);
    if (!email || !email.includes('@')) {
      return { success: false, message: 'يُرْجَى كِتَابَةُ بَرِيدٍ إِلِكْتَرُونِيٍّ صَحِيحٍ' };
    }
    return {
      success: true,
      message: `تَمَّ إِرْسَالُ رَابِطِ اسْتِعَادَةِ كَلِمَةِ الْمُرُورِ إِلَى «${email}». يُرْجَى مُرَاجَعَةُ صُنْدُوقِ الْوَارِدِ.`,
    };
  };

  const logout = () => {
    saveUserSession(null);
  };

  const syncProgressNow = async () => {
    setIsSyncing(true);
    setLastSyncMessage('جَارٍ مُزَامَنَةُ تَقَدُّمِ الطِّفْلِ مَعَ السَّحَابَة...');
    await new Promise((r) => setTimeout(r, 900));
    setProgress((prev) => ({
      ...prev,
      lastSyncedAt: new Date().toISOString(),
    }));
    setIsSyncing(false);
    setLastSyncMessage('تَمَّتِ الْمُزَامَنَةُ السَّحَابِيَّةُ بِنَجَاحٍ عَلَى جَمِيعِ الْأَجْهِزَةِ!');
    setTimeout(() => setLastSyncMessage(null), 4000);
  };

  const addCompletedLetter = (letterId: string) => {
    setProgress((prev) => {
      if (prev.completedLetters.includes(letterId)) return prev;
      return {
        ...prev,
        completedLetters: [...prev.completedLetters, letterId],
        starsCount: prev.starsCount + 3,
      };
    });
  };

  const addCompletedWord = (wordId: string) => {
    setProgress((prev) => {
      if (prev.completedWords.includes(wordId)) return prev;
      return {
        ...prev,
        completedWords: [...prev.completedWords, wordId],
        starsCount: prev.starsCount + 2,
      };
    });
  };

  const addStars = (amount: number) => {
    setProgress((prev) => ({
      ...prev,
      starsCount: prev.starsCount + amount,
    }));
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        isAuthenticated: !!user,
        isLoading,
        progress,
        isSyncing,
        lastSyncMessage,
        loginWithGoogle,
        loginWithApple,
        loginWithEmail,
        registerWithEmail,
        recoverPassword,
        logout,
        syncProgressNow,
        addCompletedLetter,
        addCompletedWord,
        addStars,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
